<?php
require_once("common.php");

function handleInput()
{
    $directoryName = getRequestParameter("DirectoryName");
    $fileName = getRequestParameter("FileName");
    $title = getRequestParameter("Title");
    $note = getRequestParameter("Note");
    return addNote($directoryName, $fileName, $title, $note);
}

$topBannerText = "";
$directoryName = getRequestParameter("DirectoryName");
$fileName = getRequestParameter("FileName");

$title = "";
$note = "";
if ($fileName !== "") {
    $data = getNote($directoryName, $fileName);
    if (isset($data)) {
        $title = $data->title;
        $note = $data->note;
    }
}

if (getRequestParameter("submit") === "yes") {
    $fileName = handleInput();
    if (strlen($fileName) > 0) {
        $topBannerText = "<p class=\"text-primary\">新しいノートが追加されました。</p>";
        $scrollToID = $directoryName . "_" . $fileName;
        header("Location: ./?ScrollToID=" . $scrollToID);
        exit(0);
    }
}

print($twig->render('header.html', []));
print($twig->render('add_note.html', ["TopBannerText" => $topBannerText, "DirectoryName" => $directoryName, "FileName" => $fileName, "Title" => $title, "Note" => $note]));
print($twig->render('footer.html', []));
