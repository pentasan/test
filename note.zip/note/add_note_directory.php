<?php
require_once("common.php");

function handleInput()
{
    $directoryName = getRequestParameter("DirectoryName");
    $categoryName = getRequestParameter("CategoryName");
    return editNoteDirectory($directoryName, $categoryName);
}

$topBannerText = "";
$title = "";
$directoryName = getRequestParameter("DirectoryName");
if ($directoryName !== "") {
    $noteDirectory = getNoteDirectory($directoryName);
    if (isset($noteDirectory)) {
        $title = $noteDirectory->title;
    }
}

if (getRequestParameter("submit") === "yes") {
    if (handleInput()) {
        $topBannerText = "<p class=\"text-primary\">新しいカテゴリが追加されました。</p>";
        header("Location: ./");
        exit(0);
    }
}

print($twig->render('header.html', []));
print($twig->render('add_note_directory.html', ["DirectoryName" => $directoryName, "TopBannerText" => $topBannerText, "Title" => $title]));
print($twig->render('footer.html', []));
