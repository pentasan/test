<?php
require_once("commonObjects.php");

$GLOBAL_NOTE_DIRECTORY = "dat";

require_once __DIR__ . '\\vendor\\autoload.php';
$loader = new \Twig\Loader\FilesystemLoader(__DIR__ . '\\templates\\');
$twig = new \Twig\Environment($loader, []);

function getNewNoteFileName($directoryName)
{
    global $GLOBAL_NOTE_DIRECTORY;
    $ret = 0;
    $fullDirectoryName = $GLOBAL_NOTE_DIRECTORY . "/" . $directoryName;
    if (is_dir($fullDirectoryName)) {
        if ($dh = opendir($fullDirectoryName)) {
            while (($file = readdir($dh)) !== false) {
                if (!is_numeric($file)) {
                    continue;
                }
                $n = (int)($file);
                if ($n > $ret) {
                    $ret = $n;
                }
            }
        }
    }
    $ret = $ret + 1;
    return $ret;
}
function addNote($directoryName, $fileName, $title, $note)
{
    global $GLOBAL_NOTE_DIRECTORY;
    if ($fileName == "") {
        $fileName = getNewNoteFileName($directoryName);
    }
    $fullFileName = $GLOBAL_NOTE_DIRECTORY . "/" . $directoryName . "/" . $fileName;

    $fileContent = $title . "\r\n" . $note;
    file_put_contents($fullFileName, $fileContent);
    return $fileName;
}
function getNewNoteDirectoryName()
{
    global $GLOBAL_NOTE_DIRECTORY;
    $ret = 0;
    if (is_dir($GLOBAL_NOTE_DIRECTORY)) {
        if ($dh = opendir($GLOBAL_NOTE_DIRECTORY)) {
            while (($file = readdir($dh)) !== false) {
                if (!is_numeric($file)) {
                    continue;
                }
                $n = (int)($file);
                if ($n > $ret) {
                    $ret = $n;
                }
            }
        }
    }
    $ret = $ret + 1;
    return $ret;
}
function editNoteDirectory($directoryName, $categoryName)
{
    global $GLOBAL_NOTE_DIRECTORY;
    $fullDirectoryName = "";
    if ($directoryName === "") {
        $newDirectoryName = getNewNoteDirectoryName();
        $fullDirectoryName = $GLOBAL_NOTE_DIRECTORY . "/" . $newDirectoryName;
        if (!mkdir($fullDirectoryName)) {
            return false;
        }
    } else {
        $fullDirectoryName = $GLOBAL_NOTE_DIRECTORY . "/" . $directoryName;
    }
    $titleFileName = getNoteDirectoryTitleFileName($fullDirectoryName);
    return file_put_contents($titleFileName, $categoryName);
}
function getNoteDirectoryTitleFileName($directoryName)
{
    return $directoryName . "/title";
}
function isFileNameNote($fileName)
{
    return is_numeric($fileName);
}
function getNoteFromNoteFile($fileName, $fullFileName)
{
    $title = "";
    $note = "";
    $list = file($fullFileName);
    $count = 0;
    foreach ($list as $line) {
        $count = $count + 1;
        if ($count == 1) {
            $title .= $line;
        } else {
            $note .= $line;
        }
    }
    return new Note($fileName, $title, $note);
}
function getNoteListFromDirectory($directoryName)
{
    $ret = array();
    if (is_dir($directoryName)) {
        if ($dh = opendir($directoryName)) {
            while (($file = readdir($dh)) !== false) {
                if (!isFileNameNote($file)) {
                    continue;
                }
                $fullFileName = $directoryName . "/" . $file;
                //error_log("fffffffffffffff:" . $fileName);
                array_push($ret, getNoteFromNoteFile($file, $fullFileName));
            }
        }
    }
    usort($ret, "NoteFileNameComparator");
    return $ret;
}
function getNote($directoryName, $fileName)
{
    global $GLOBAL_NOTE_DIRECTORY;
    $fullFileName = $GLOBAL_NOTE_DIRECTORY . "/" . $directoryName . "/" . $fileName;
    return getNoteFromNoteFile($fileName, $fullFileName);
}
function getNoteDirectory($directoryName)
{
    global $GLOBAL_NOTE_DIRECTORY;

    $fullDirectoryName = $GLOBAL_NOTE_DIRECTORY . "/" . $directoryName;
    $titleFileName = getNoteDirectoryTitleFileName($fullDirectoryName);
    if (!file_exists($titleFileName)) {
        return null;
    }
    $title = file_get_contents($titleFileName);
    $noteList = getNoteListFromDirectory($fullDirectoryName);
    return new NoteDirectory($directoryName, $title, $noteList);
}
function getNoteDirectoryList()
{
    global $GLOBAL_NOTE_DIRECTORY;
    $ret = array();
    if (is_dir($GLOBAL_NOTE_DIRECTORY)) {
        if ($dh = opendir($GLOBAL_NOTE_DIRECTORY)) {
            while (($file = readdir($dh)) !== false) {
                if ($file === "." || $file === "..") {
                    continue;
                }
                $noteDirectory = getNoteDirectory($file);
                if (isset($noteDirectory)) {
                    array_push($ret, $noteDirectory);
                }
            }
        }
    }
    usort($ret, "NoteDirectoryDirectroryNameComparator");
    return $ret;
}
function getRequestParameter($name)
{
    if (isset($_POST[$name])) {
        return $_POST[$name];
    }
    if (isset($_GET[$name])) {
        return $_GET[$name];
    }
    return "";
}
