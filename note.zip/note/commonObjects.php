<?php

class NoteDirectory
{
    var $directoryName;
    var $title;
    var $noteList;

    public function __construct($directoryName, $title, $noteList)
    {
        $this->directoryName = $directoryName;
        $this->title = $title;
        $this->noteList = $noteList;
    }
}
class Note
{
    var $fileName;
    var $title;
    var $note;

    public function __construct($fileName, $title, $note)
    {
        $this->fileName = $fileName;
        $this->title = $title;
        $this->note = $note;
    }

    function getNoteHTMLForDisplay()
    {
        $ret = "";
        $l = explode("\r\n", $this->note);
        foreach ($l as $line) {
            if (strlen($line) <= 0) {
                $line = "&nbsp;";
            }
            $ret .= "<p class=\"my-0 py-0\"><small>" . $line . "</small></p>\r\n";
        }
        return $ret;
    }
}
function NoteFileNameComparator($a, $b)
{
    $fileNameA = $a->fileName;
    $fileNameB = $b->fileName;
    $fileNameA = (int)($fileNameA);
    $fileNameB = (int)($fileNameB);
    if ($fileNameA == $fileNameB) {
        return 0;
    } else if ($fileNameA > $fileNameB) {
        return 1;
    } else {
        return -1;
    }
}
function NoteDirectoryDirectroryNameComparator($a, $b)
{
    $directoryNameA = $a->directoryName;
    $directoryNameB = $b->directoryName;
    $directoryNameA = (int)($directoryNameA);
    $directoryNameB = (int)($directoryNameB);
    if ($directoryNameA == $directoryNameB) {
        return 0;
    } else if ($directoryNameA > $directoryNameB) {
        return 1;
    } else {
        return -1;
    }
}
