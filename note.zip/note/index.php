<?php
require_once("common.php");

function getCategoryListText($noteDirectoryList)
{
    $ret = "";
    foreach ($noteDirectoryList as $noteDirectory) {
        $ret .= "<button type=\"button\" class=\"btn btn-sm bg-pink mx-1 px-3\" data-bs-toggle=\"tooltip\" onclick=\"scrollToID('#Category" . $noteDirectory->directoryName . "')\" data-bs-placement=\"left\" title=\"" . $noteDirectory->title . "\">" . $noteDirectory->directoryName . "</button>";
    }
    return $ret;
}
function getNoteDirectoryText($noteDirectory)
{
    $ret = "";
    $ret .= "<div class=\"container px-0 mb-1 bg-pink note\" style=\"min-width:98%;\">\r\n";
    $ret .= "  <div class=\"row bg-pink\">\r\n";
    $ret .= "    <div class=\"col-1\" id=\"Category" . $noteDirectory->directoryName . "\">\r\n";
    $ret .= "<p class=\"my-0 fw-bolder\">" . $noteDirectory->directoryName . "</p>\r\n";
    $ret .= "    </div>\r\n";
    $ret .= "    <div class=\"col-8\">\r\n";
    $ret .= "<p class=\"my-0 fw-bolder\">" . $noteDirectory->title . "</p>\r\n";
    $ret .= "    </div>\r\n";
    $ret .= "    <div class=\"col-1\">\r\n";
    $ret .= "<a class=\"btn btn-primary btn-sm\" href=\"add_note_directory.php?DirectoryName=" . $noteDirectory->directoryName . "\">編集</a>\r\n";
    $ret .= "    </div>\r\n";
    $ret .= "    <div class=\"col-2\">\r\n";
    $ret .= "<a class=\"btn btn-primary btn-sm\" href=\"add_note.php?DirectoryName=" . $noteDirectory->directoryName . "\">新しいノートを追加</a>\r\n";
    $ret .= "    </div>\r\n";
    $ret .= "  </div>\r\n";
    $ret .= "</div>\r\n";

    foreach ($noteDirectory->noteList as $note) {
        $ret .= "<div class=\"container px-0 mb-3 note\" id=\"" . $noteDirectory->directoryName . "_" . $note->fileName . "\"  style=\"min-width:98%;\">\r\n";
        $ret .= "  <div class=\"row bg-lightgreen\">\r\n";
        $ret .= "    <div class=\"col-1\">\r\n";
        $ret .= "<p class=\"my-0 fw-bold\">" . $noteDirectory->directoryName . "-" . $note->fileName . "</p>\r\n";
        $ret .= "    </div>\r\n";
        $ret .= "    <div class=\"col-9\">\r\n";
        $ret .= "<p class=\"my-0\"><span class=\"pb-1 fw-bold\">" . $note->title . "</span></p>\r\n";
        $ret .= "    </div>\r\n";
        $ret .= "    <div class=\"col-2\">\r\n";
        $ret .= "<a class=\"btn btn-primary btn-sm\" href=\"add_note.php?DirectoryName=" . $noteDirectory->directoryName . "&FileName=" . $note->fileName . "\">ノートを編集</a>\r\n";
        $ret .= "    </div>\r\n";
        $ret .= "  </div>\r\n";
        $ret .= "  <div class=\"row\">\r\n";
        $ret .=  $note->getNoteHTMLForDisplay();
        $ret .= "  </div>\r\n";
        $ret .= "</div>\r\n";
    }
    return $ret;
}
function getNoteListText($noteDirectoryList)
{
    $ret = "";
    foreach ($noteDirectoryList as $noteDirectory) {
        $ret .= getNoteDirectoryText($noteDirectory);
    }
    return $ret;
}

$scrollToID = getRequestParameter("ScrollToID");

$noteDirectoryList = getNoteDirectoryList();

print($twig->render('header.html', []));
print($twig->render('index.html', ["CategoryListText" => getCategoryListText($noteDirectoryList), "NoteListText" => getNoteListText($noteDirectoryList), "ScrollToID" => $scrollToID]));
print($twig->render('footer.html', []));
