require 'overload_copy'

include Overload_copy

f = Foo.new
g = Foo.new(f)
