package jp.ne.sakura.jun28.symphonytest;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.DefaultHandler;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;
import org.eclipse.jetty.servlet.ServletHandler;

import authentication.SymBotRSAAuth;
import clients.SymBotClient;
import configuration.SymConfig;
import listeners.ConnectionListener;
import listeners.IMListener;
import listeners.RoomListener;
import model.InboundMessage;
import model.OutboundMessage;
import model.Stream;
import model.StreamListItem;
import model.User;
import model.events.RoomCreated;
import model.events.RoomDeactivated;
import model.events.RoomMemberDemotedFromOwner;
import model.events.RoomMemberPromotedToOwner;
import model.events.RoomUpdated;
import model.events.UserJoinedRoom;
import model.events.UserLeftRoom;
import services.DatafeedEventsService;

public class Bchan {

	private static SymBotClient _botClient;

	private static List<Room> _roomList = new ArrayList<Room>();

	public Bchan() {
		SymConfig config = Utility.getSymConfig();
		SymBotRSAAuth botAuth = new SymBotRSAAuth(config);
		botAuth.authenticate();
		_botClient = SymBotClient.initBot(config, botAuth);
		// set my presence to Available
		_botClient.getPresenceClient().setPresence("Available");

		DatafeedEventsService datafeedEventsService = _botClient.getDatafeedEventsService();
		datafeedEventsService.addRoomListener(new RoomListenerTestImpl(_botClient));
		datafeedEventsService.addIMListener(new IMListenerImpl(_botClient));
		datafeedEventsService.addConnectionsListener(new ConnectionListenerImpl(_botClient));
		System.out.println("connected.");

		// get room list
		List<String> streamTypeList = new ArrayList<String>();
		streamTypeList.add("ROOM");
		List<StreamListItem> list = _botClient.getStreamsClient().getUserStreams(streamTypeList, false);
		for (StreamListItem item : list) {
			String id = item.getId();
			String name = item.getRoomAttributes().getName();
			_roomList.add(new Room(id, name));
		}

		startJetty();
	}

	private void startJetty() {
		try {
			System.out.println("starting jetty...");
			Server server = new Server(8080);

			ResourceHandler resourceHandler = new ResourceHandler();
			resourceHandler.setDirectoriesListed(true);
			resourceHandler.setWelcomeFiles(new String[] { "index.html" });
			resourceHandler.setResourceBase("web");

			ServletHandler handler = new ServletHandler();
			server.setHandler(handler);
			handler.addServletWithMapping(TopPageServlet.class, "/top");
			handler.addServletWithMapping(EditCommandServlet.class, "/editcommand");
			handler.addServletWithMapping(DeleteCommandServlet.class, "/deletecommand");
			handler.addServletWithMapping(PushMessageServlet.class, "/pushmessage");

			HandlerList handlers = new HandlerList();
			handlers.setHandlers(new Handler[] { resourceHandler, handler, new DefaultHandler() });
			server.setHandler(handlers);

			server.start();
			server.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void sendCommandDetailMessage(SymBotClient botClient, String streamID, String text) {
		OutboundMessage messageOut = new OutboundMessage();
		messageOut.setMessage(text);
		botClient.getMessagesClient().sendMessage(streamID, messageOut);
		try {
			MessageLog messageLog = new MessageLog("OUT", System.currentTimeMillis(), getRoomNameFromStreamId(streamID),
					text);
			MessageLog.appendLog(messageLog);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void sendMessageWithAttachment(SymBotClient botClient, String streamID, String text, String fileName) {
		OutboundMessage messageOut = new OutboundMessage();
		messageOut.setMessage(text);
		File files[] = new File[1];
		files[0] = new File(fileName);
		messageOut.setAttachment(files);
		botClient.getMessagesClient().sendMessage(streamID, messageOut);
		try {
			MessageLog messageLog = new MessageLog("OUT", System.currentTimeMillis(), getRoomNameFromStreamId(streamID),
					text);
			MessageLog.appendLog(messageLog);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getRoomNameFromStreamId(String id) {
		for (Room room : _roomList) {
			if (room.getId().equals(id)) {
				return room.getName();
			}
		}
		return id;
	}

	private void handleMessage(SymBotClient botClient, InboundMessage inboundMessage) {
		try {
			MessageLog messageLog = new MessageLog("IN", System.currentTimeMillis(),
					getRoomNameFromStreamId(inboundMessage.getStream().getStreamId()), inboundMessage.getMessageText());
			MessageLog.appendLog(messageLog);
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			String message = inboundMessage.getMessageText();
			Command command = CommandProvider.getInstance().getCommandFromChatMessage(message);
			if (command != null) {
				HttpResponse response = command.getWebhookReply(inboundMessage.getUser().getUserId(),
						inboundMessage.getUser().getDisplayName(), inboundMessage.getUser().getEmail(), message);
				if (response.isResponesTypeText()) {
					String text = new String(response.getContent());
					sendCommandDetailMessage(botClient, inboundMessage.getStream().getStreamId(), text);
				} else if (response.isResponesTypeImage()) {
					String outputFileName = System.currentTimeMillis() + "." + response.getImageExtension();
					String fileName = "web/imgtmp/" + outputFileName;
					Utility.saveFileContent(fileName, response.getContent());
					String text = "<img src=\"http://localhost:8080/imgtmp/" + outputFileName + "\"/>";
					sendCommandDetailMessage(botClient, inboundMessage.getStream().getStreamId(), text);
				} else {
					String outputFileName = System.currentTimeMillis() + "." + response.getFileExtension();
					String fileName = "web/dattmp/" + outputFileName;
					Utility.saveFileContent(fileName, response.getContent());
					String text = "Attachment file:";
					sendMessageWithAttachment(botClient, inboundMessage.getStream().getStreamId(), text, fileName);
				}
			} else {
				sendCommandDetailMessage(botClient, inboundMessage.getStream().getStreamId(),
						CommandProvider.getInstance().getCommandDetailText());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String getCommandTableHTML() {
		StringBuffer sb = new StringBuffer();
		sb.append("<table class=\"table table-striped table-bordered table-hover table-sm\">");
		sb.append("<thead><tr><th>Command</th><th>Parameter</th><th>Detail</th><th>WebHook</th></tr></thead>");
		sb.append("<tbody>");
		List<Command> list = CommandProvider.getInstance().getCommandList();
		for (Command command : list) {
			sb.append("<tr><td><A HREF=\"editcommand?command=" + command.getCommand() + "\">" + command.getCommand()
					+ "</A></td><td>" + command.getParameter() + "</td><td>" + command.getDetail() + "</td><td>"
					+ command.getWebHook() + "</td></tr>");
		}
		sb.append("</tbody>");
		sb.append("</table>");
		return sb.toString();
	}

	private static String getRoomTableHTML() {
		StringBuffer sb = new StringBuffer();
		sb.append("<table class=\"table table-striped table-bordered table-hover table-sm\">");
		sb.append("<thead><tr><th>Id</th><th>Room Name</th></tr></thead>");
		sb.append("<tbody>");
		for (Room room : _roomList) {
			sb.append("<tr><td>" + room.getId() + "</td><td>" + room.getName() + "</td></tr>");
		}
		sb.append("</tbody>");
		sb.append("</table>");
		return sb.toString();
	}

	private static String getMessageTableHTML() {
		StringBuffer sb = new StringBuffer();
		try {
			sb.append("<table class=\"table table-striped table-bordered table-hover table-sm\">");
			sb.append("<thead><tr><th>Type</th><th>Time</th><th>Room Name</th><th>Message</th></tr></thead>");
			sb.append("<tbody>");
			List<MessageLog> list = MessageLog.getMessageLogList();
			Collections.reverse(list);
			for (MessageLog msg : list) {
				sb.append("<tr><td>" + msg.getType() + "</td><td>" + msg.getTimeForDisplay() + "</td><td>"
						+ msg.getRoomName() + "</td><td>" + msg.getMessage() + "</td></tr>");
			}
			sb.append("</tbody>");
			sb.append("</table>");
		} catch (Exception e) {
		}
		return sb.toString();
	}

	private static void sendResponseToBrowser(HttpServletRequest request, HttpServletResponse response,
			String templateFileName, String... parameterList) throws IOException {
		VelocityEngine velocityEngine = new VelocityEngine();
		velocityEngine.init();
		Template t = velocityEngine.getTemplate(templateFileName);
		VelocityContext context = new VelocityContext();
		// System.out.println("parameterList.length:" + parameterList.length);
		for (int i = 0; i < parameterList.length; i += 2) {
			String name = parameterList[i];
			String value = parameterList[i + 1];
			// System.out.println("name:" + name + " value:" + value);
			context.put(name, value);
		}
		StringWriter writer = new StringWriter();
		t.merge(context, writer);

		response.setContentType("text/html");
		response.setStatus(HttpServletResponse.SC_OK);
		response.getWriter().println(writer.getBuffer().toString());
	}

	public static class TopPageServlet extends HttpServlet {
		private static final long serialVersionUID = -5730270365520062867L;

		@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			VelocityEngine velocityEngine = new VelocityEngine();
			velocityEngine.init();
			Template t = velocityEngine.getTemplate("web/top.tpl");
			VelocityContext context = new VelocityContext();
			context.put("commandtable", getCommandTableHTML());
			context.put("roomtable", getRoomTableHTML());
			context.put("messagetable", getMessageTableHTML());
			StringWriter writer = new StringWriter();
			t.merge(context, writer);

			response.setContentType("text/html");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().println(writer.getBuffer().toString());
		}
	}

	public static class EditCommandServlet extends HttpServlet {

		private static final long serialVersionUID = 8547376396432011321L;

		private boolean isSubmittingEditCommand(HttpServletRequest request) {
			if ("yes".equalsIgnoreCase(request.getParameter("submit"))) {
				return true;
			}
			return false;
		}

		private void handleEditCommandRequest(HttpServletRequest request) {
			String command = request.getParameter("command");
			String parameter = request.getParameter("parameter");
			String detail = request.getParameter("detail");
			String webhook = request.getParameter("webhook");
			System.out.println(
					"command:" + command + " parameter:" + parameter + " deteail:" + detail + " webhook:" + webhook);
			Command c = new Command(command, parameter, detail, webhook);
			CommandProvider.getInstance().upsertCommand(c);
			try {
				CommandProvider.getInstance().saveData();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		private String[] getEditCommandParameterList(HttpServletRequest request) {
			String command = request.getParameter("command");
			String ret[] = new String[] { "command", "", "parameter", "", "detail", "", "webhook", "", "deletebutton",
					"" };
			if (Utility.isEmptyString(command)) {
				return ret;
			}
			Command c = CommandProvider.getInstance().getCommandByName(command);
			if (c != null) {
				ret[1] = c.getCommand();
				ret[3] = c.getParameter();
				ret[5] = c.getDetail();
				ret[7] = c.getWebHook();
				ret[9] = "<div style=\"text-align:center;padding:100px 0px 0px 0px;\"><A HREF=\"deletecommand?command="
						+ c.getCommand() + "\" class=\"btn btn-danger\">Delete this command</A></div>";
			}
			return ret;
		}

		@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			if (isSubmittingEditCommand(request)) {
				handleEditCommandRequest(request);
				sendResponseToBrowser(request, response, "web/editcommand_done.tpl");
				return;
			}
			String commandParameterList[] = getEditCommandParameterList(request);
			sendResponseToBrowser(request, response, "web/editcommand.tpl", commandParameterList);
		}
	}

	public static class DeleteCommandServlet extends HttpServlet {

		private static final long serialVersionUID = -6437015665362113665L;

		private void handleDeleteCommandRequest(HttpServletRequest request) {
			String command = request.getParameter("command");
			System.out.println("deletecommand:" + command);

			CommandProvider.getInstance().deleteCommand(command);
			try {
				CommandProvider.getInstance().saveData();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			handleDeleteCommandRequest(request);
			sendResponseToBrowser(request, response, "web/deletecommand_done.tpl");
		}
	}

	public static class PushMessageServlet extends HttpServlet {

		private static final long serialVersionUID = 992999465809335720L;

		private void handlePushMessageRequest(HttpServletRequest request) {
			String roomid = request.getParameter("roomid");
			String message = request.getParameter("message");
			System.out.println("roomid:" + roomid);
			System.out.println("message:" + message);

			sendCommandDetailMessage(_botClient, roomid, message);

//			CommandProvider.getInstance().deleteCommand(command);
//			try {
//				CommandProvider.getInstance().saveData();
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
		}

		@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			handlePushMessageRequest(request);

			response.setContentType("text/html");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().println("ok");
		}
	}

	private class ConnectionListenerImpl implements ConnectionListener {

		private SymBotClient _botClient;

		public ConnectionListenerImpl(SymBotClient botClient) {
			_botClient = botClient;
		}

		public void onConnectionAccepted(User user) {
			System.out.println("onConnectionAccepted callled.");
		}

		public void onConnectionRequested(User user) {
			System.out.println("onConnectionReqested called.");
		}

	}

	private class IMListenerImpl implements IMListener {

		private SymBotClient _botClient;

		public IMListenerImpl(SymBotClient client) {
			_botClient = client;
		}

		public void onIMMessage(InboundMessage inboundMessage) {
			System.out.println("onIMMessage called.");
			handleMessage(_botClient, inboundMessage);
		}

		public void onIMCreated(Stream stream) {
			System.out.println("onIMCreated called.");
		}

	}

	private class RoomListenerTestImpl implements RoomListener {

		// private final Logger logger =
		// LoggerFactory.getLogger(RoomListenerTestImpl.class);

		private SymBotClient _botClient;

		public RoomListenerTestImpl(SymBotClient botClient) {
			_botClient = botClient;
		}

		public void onRoomMessage(InboundMessage inboundMessage) {
			System.out.println("onRoomMessage called.");
			handleMessage(_botClient, inboundMessage);
		}

		public void onRoomCreated(RoomCreated roomCreated) {
			System.out.println("onRoomCreated.");
		}

		public void onRoomDeactivated(RoomDeactivated roomDeactivated) {
			System.out.println("onRoomDeactivated.");
		}

		public void onRoomMemberDemotedFromOwner(RoomMemberDemotedFromOwner roomMemberDemotedFromOwner) {
			System.out.println("onRoomMemberDemotedFromOwner called.");
		}

		public void onRoomMemberPromotedToOwner(RoomMemberPromotedToOwner roomMemberPromotedToOwner) {
			System.out.println("onRoomMemberPromotedToOwner called.");
		}

		public void onRoomUpdated(RoomUpdated roomUpdated) {
			System.out.println("onRoomUpdated called.");
		}

		public void onUserJoinedRoom(UserJoinedRoom userJoinedRoom) {
			System.out.println("onUserJoinedRoom called.");
			OutboundMessage messageOut = new OutboundMessage();
			messageOut.setMessage("Welcome " + userJoinedRoom.getAffectedUser().getFirstName() + "!");
			try {
				_botClient.getMessagesClient().sendMessage(userJoinedRoom.getStream().getStreamId(), messageOut);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onUserLeftRoom(UserLeftRoom userLeftRoom) {
			System.out.println("onUserLeftRoom called.");
		}

		public void onRoomReactivated(Stream stream) {
			System.out.println("onRoomReactivated called.");
		}
	}

	public static void main(String[] args) {
		new Bchan();
	}

}
