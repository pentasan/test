package jp.ne.sakura.jun28.symphonytest;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.apache.commons.io.output.ByteArrayOutputStream;

public class Command {

	private static final String ITEM_SEPARATOR = "\t";

	private String _command;
	private String _parameter;
	private String _detail;
	private String _webHook;

	public Command(String command, String parameter, String detail, String webHook) {
		super();
		_command = command;
		_parameter = parameter;
		_detail = detail;
		_webHook = webHook;
	}

	public static Command parse(String line) {
		if (Utility.isEmptyString(line)) {
			return null;
		}
		String l[] = line.split(ITEM_SEPARATOR);
		if (l.length != 4) {
			return null;
		}
		return new Command(l[0], l[1], l[2], l[3]);
	}

	public String getLine() {
		return _command + ITEM_SEPARATOR + _parameter + ITEM_SEPARATOR + _detail + ITEM_SEPARATOR + _webHook;
	}

	public String getCommand() {
		return _command;
	}

	public void setCommand(String command) {
		_command = command;
	}

	public String getParameter() {
		return _parameter;
	}

	public void setParameter(String parameter) {
		_parameter = parameter;
	}

	public String getDetail() {
		return _detail;
	}

	public void setDetail(String detail) {
		_detail = detail;
	}

	public String getWebHook() {
		return _webHook;
	}

	public void setWebHook(String webHook) {
		_webHook = webHook;
	}

	private static HttpResponse callPost(String strPostUrl, String formParam) throws Exception {
		HttpURLConnection connection = null;
		InputStream in = null;
		ByteArrayOutputStream baos = null;
		try {

			URL url = new URL(strPostUrl);

			connection = (HttpURLConnection) url.openConnection();

			connection.setDoOutput(true);
			connection.setRequestMethod("POST");
			OutputStreamWriter out = new OutputStreamWriter(connection.getOutputStream());
			out.write(formParam);
			out.close();
			connection.connect();

			final int status = connection.getResponseCode();
			if (status == HttpURLConnection.HTTP_OK) {
				String contentType = connection.getContentType();
				System.out.println("contentType:" + contentType);
				in = connection.getInputStream();
				baos = new ByteArrayOutputStream();
				byte b[] = new byte[1024];
				while (true) {
					int len = in.read(b);
					if (len < 0) {
						break;
					}
					baos.write(b, 0, len);
				}
				return new HttpResponse(contentType, baos.toByteArray());
			} else {
				throw new Exception("HTTP Response was " + status);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (baos != null) {
				try {
					baos.close();
				} catch (Exception e) {
				}
				baos = null;
			}
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
				in = null;
			}
			if (connection != null) {
				connection.disconnect();
			}
		}
	}

	private String getPostParameterURL(String name, String email, String message) throws UnsupportedEncodingException {
		return "name=" + URLEncoder.encode(name, "UTF-8") + "&email=" + URLEncoder.encode(email, "UTF-8") + "&message="
				+ URLEncoder.encode(message, "UTF-8");
	}

	private String removeCommandPart(String message) {
		int pos = message.indexOf(" ");
		if (pos < 0) {
			return message;
		}
		return message.substring(pos + 1);
	}

	public HttpResponse getWebhookReply(long userID, String name, String email, String message) {
		message = removeCommandPart(message);
		try {
			return callPost(_webHook, getPostParameterURL(name, email, message));
		} catch (Exception e) {
			StringWriter stringWriter = new StringWriter();
			PrintWriter printWriter = new PrintWriter(stringWriter);
			e.printStackTrace(printWriter);
			printWriter.flush();
			return new HttpResponse("text/plain", stringWriter.toString().getBytes());
		}
	}

	@Override
	public String toString() {
		return "Command [_command=" + _command + ", _parameter=" + _parameter + ", _detail=" + _detail + ", _webHook="
				+ _webHook + "]";
	}

}
