package jp.ne.sakura.jun28.symphonytest;

import java.util.ArrayList;
import java.util.List;

public class CommandProvider {

	private static final String CONFIG_FILE_NAME = "command.cfg";

	private static CommandProvider _instance = new CommandProvider();

	private List<Command> _commandList = new ArrayList<Command>();

	private CommandProvider() {
		loadData();
	}

	public Command getCommandByName(String c) {
		for (Command command : _commandList) {
			if (command.getCommand().equals(c)) {
				return command;
			}
		}
		return null;
	}

	public List<Command> getCommandList() {
		List<Command> ret = new ArrayList<Command>();
		ret.addAll(_commandList);
		return ret;
	}

	public void addCommand(Command command) {
		_commandList.add(command);
	}

	private int getPositionInCommandList(Command command) {
		for (int i = 0; i < _commandList.size(); i++) {
			String commandText = _commandList.get(i).getCommand();
			if (command.getCommand().equals(commandText)) {
				return i;
			}
		}
		return -1;
	}

	public void upsertCommand(Command command) {
		int pos = getPositionInCommandList(command);
		if (pos >= 0) {
			_commandList.set(pos, command);
		} else {
			_commandList.add(command);
		}
	}

	public void updateCommand(Command command) {
		int pos = getPositionInCommandList(command);
		if (pos < 0) {
			return;
		}
		_commandList.set(pos, command);
	}

	public void deleteCommand(String command) {
		int pos = -1;
		for (int i = 0; i < _commandList.size(); i++) {
			Command c = _commandList.get(i);
			if (command.equals(c.getCommand())) {
				pos = i;
				break;
			}
		}
		if (pos < 0) {
			return;
		}
		_commandList.remove(pos);
	}

	private void loadData() {
		try {
			String text = Utility.loadTextFileContent(CONFIG_FILE_NAME);
			String l[] = text.split("[\r\n]+");
			for (String line : l) {
				Command command = Command.parse(line);
				if (command != null) {
					_commandList.add(command);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private String getConfigFileContent() {
		StringBuffer sb = new StringBuffer();
		for (Command command : _commandList) {
			sb.append(command.getLine());
			sb.append("\r\n");
		}
		return sb.toString();
	}

	public void saveData() throws Exception {
		String text = getConfigFileContent();
		Utility.saveTextFileContent(CONFIG_FILE_NAME, text);
	}

	private String getCommandFromChatMessageText(String message) {
		if (Utility.isEmptyString(message)) {
			return "";
		}
		int pos = message.indexOf(" ");
		if (pos < 0) {
			return message;
		}
		return message.substring(0, pos);
	}

	public Command getCommandFromChatMessage(String message) {
		String command = getCommandFromChatMessageText(message);
		if (Utility.isEmptyString(command)) {
			return null;
		}
		for (Command c : _commandList) {
			if (command.equals(c.getCommand())) {
				return c;
			}
		}
		return null;
	}

	public String getCommandDetailText() {
		StringBuffer sb = new StringBuffer();
		sb.append("Followings are the list of available commands:<br/>");
		sb.append("<table>");
		sb.append("<tr><th>Command</th><th>Parameter</th><th>Detail</th></tr>");
		for (Command command : _commandList) {
			sb.append("<tr><td>" + command.getCommand() + "</td><td>" + command.getParameter() + "</td><td>"
					+ command.getDetail() + "</td></tr>");
		}
		sb.append("</table>");
		return sb.toString();
	}

	public static CommandProvider getInstance() {
		return _instance;
	}
}
