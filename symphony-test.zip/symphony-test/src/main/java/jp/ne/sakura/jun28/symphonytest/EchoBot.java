package jp.ne.sakura.jun28.symphonytest;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import authentication.SymBotRSAAuth;
import clients.SymBotClient;
import configuration.SymConfig;
import listeners.ConnectionListener;
import listeners.IMListener;
import listeners.RoomListener;
import model.Attachment;
import model.InboundMessage;
import model.OutboundMessage;
import model.RoomMember;
import model.Stream;
import model.StreamListItem;
import model.User;
import model.UserInfo;
import model.events.RoomCreated;
import model.events.RoomDeactivated;
import model.events.RoomMemberDemotedFromOwner;
import model.events.RoomMemberPromotedToOwner;
import model.events.RoomUpdated;
import model.events.UserJoinedRoom;
import model.events.UserLeftRoom;
import services.DatafeedEventsService;

public class EchoBot {

	public EchoBot() {
		SymConfig config = Utility.getSymConfig();
		SymBotRSAAuth botAuth = new SymBotRSAAuth(config);
		botAuth.authenticate();
		SymBotClient botClient = SymBotClient.initBot(config, botAuth);
		// set my presence to Available
		botClient.getPresenceClient().setPresence("Available");
//		try {
//			int startPos = 0;
//			int interval = 100;
//			while (true) {
//				RoomSearchQuery query = new RoomSearchQuery();
//				query.setQuery("a");
//				RoomSearchResult result = botClient.getStreamsClient().searchRooms(query, startPos, interval);
//				// int count = result.getCount();
//				int count = 0;
//				for (RoomInfo roomInfo : result.getRooms()) {
//					System.out.println("name:" + roomInfo.getRoomAttributes().getName());
//					long userID = roomInfo.getRoomSystemInfo().getCreatedByUserId();
//					UserInfo userInfo = botClient.getUsersClient().getUserFromId(userID, true);
//					System.out.println("uuu:" + userInfo.getFirstName() + " " + userInfo.getLastName() + " "
//							+ userInfo.getDepartment() + " " + userInfo.getCompany() + " " + userInfo.getEmailAddress()
//							+ " " + userInfo.getJobFunction() + " " + userInfo.getMobilePhoneNumber() + " "
//							+ userInfo.getDivision() + " " + userInfo.getLocation() + " " + userInfo.getTitle() + " "
//							+ userInfo.getWorkPhoneNumber());
//					count++;
//				}
//				System.out.println("ccc:" + count + " " + result.getCount());
//				startPos += count;
//				if (startPos >= result.getCount()) {
//					break;
//				}
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		// List<DatafeedEvent> eventList = botClient.getDatafeedClient()
		// .readDatafeed("eAjt_w9xIc_SI5xVM4W7Bn___pUdbMxZdA");
		// if (eventList != null) {
		// for (DatafeedEvent event : eventList) {
		// System.out.println(event.getMessageId() + " " + event.getType() + " " +
		// event.getId() + " "
		// + event.getTimestamp());
		// }
		// }

		// Room room = new Room();
		// room.setName("abcdefg");
		// RoomInfo roomInfo = botClient.getStreamsClient().createRoom(room);
		// System.out.println("rrr:" + roomInfo.getRoomAttributes());
		// roomInfo.getRoomSystemInfo().getId();
		// botClient.getStreamsClient().
		DatafeedEventsService datafeedEventsService = botClient.getDatafeedEventsService();
		datafeedEventsService.addRoomListener(new RoomListenerTestImpl(botClient));
		datafeedEventsService.addIMListener(new IMListenerImpl(botClient));
		datafeedEventsService.addConnectionsListener(new ConnectionListenerImpl(botClient));
		System.out.println("connected.");

		try {
			OutboundMessage messageOut = new OutboundMessage();
			messageOut.setMessage("Hi I am back here...");
			botClient.getMessagesClient().sendMessage("eAjt_w9xIc_SI5xVM4W7Bn___pUdbMxZdA", messageOut);

		} catch (Exception e) {
			e.printStackTrace();
		}
		// get room list
		List<String> streamTypeList = new ArrayList<String>();
		streamTypeList.add("ROOM");
		List<StreamListItem> list = botClient.getStreamsClient().getUserStreams(streamTypeList, false);
		for (StreamListItem item : list) {
			String id = item.getId();
			String name = item.getRoomAttributes().getName();
			System.out.println("id:" + id + " name:" + name);
		}
	}

	private class ConnectionListenerImpl implements ConnectionListener {

		private SymBotClient _botClient;

		public ConnectionListenerImpl(SymBotClient botClient) {
			_botClient = botClient;
		}

		public void onConnectionAccepted(User user) {
			System.out.println("onConnectionAccepted callled.");
		}

		public void onConnectionRequested(User user) {
			System.out.println("onConnectionReqested called.");
		}

	}

	private class IMListenerImpl implements IMListener {

		private SymBotClient _botClient;

		public IMListenerImpl(SymBotClient client) {
			_botClient = client;
		}

		public void onIMMessage(InboundMessage inboundMessage) {
			System.out.println("onIMMessage called.");

			try {

				OutboundMessage messageOut = new OutboundMessage();
				messageOut.setMessage("Hi <b>" + inboundMessage.getUser().getFirstName() + "</b>! your message is: "
						+ inboundMessage.getMessageText() + "<a href=\"http://www.hoge.com/\">aaaa</a> streamID:"
						+ inboundMessage.getStream().getStreamId());
				File files[] = new File[1];
				files[0] = new File("pom.xml");
				messageOut.setAttachment(files);
				_botClient.getMessagesClient().sendMessage(inboundMessage.getStream().getStreamId(), messageOut);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onIMCreated(Stream stream) {
			System.out.println("onIMCreated called.");
		}

	}

	private class RoomListenerTestImpl implements RoomListener {

		// private final Logger logger =
		// LoggerFactory.getLogger(RoomListenerTestImpl.class);

		private SymBotClient _botClient;

		public RoomListenerTestImpl(SymBotClient botClient) {
			_botClient = botClient;
		}

		public void onRoomMessage(InboundMessage inboundMessage) {
			try {
				List<RoomMember> roomMemberList = _botClient.getStreamsClient()
						.getRoomMembers(inboundMessage.getStream().getStreamId());
				for (RoomMember roomMember : roomMemberList) {
					System.out.println("id:" + roomMember.getId());
					try {
						UserInfo userInfo = _botClient.getUsersClient().getUserFromId(roomMember.getId(), false);
						System.out.println("userInfo:" + userInfo.getDisplayName() + " " + userInfo.getDepartment()
								+ " " + userInfo.getCompany() + " " + userInfo.getEmailAddress());
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

				System.out.println("onRoomMessage called.");
				List<Attachment> attachmentList = inboundMessage.getAttachments();
				if (attachmentList != null) {
					for (Attachment attachment : attachmentList) {
						System.out.println("attachment:" + attachment.getName() + " " + attachment.getSize() + " "
								+ attachment.getImage() + " " + attachment.getId());

						byte b[] = _botClient.getMessagesClient().getAttachment(
								inboundMessage.getStream().getStreamId(), attachment.getId(),
								inboundMessage.getMessageId());
						System.out.println("bbbbbbb.length:" + b.length);
					}
				}
				OutboundMessage messageOut = new OutboundMessage();
				messageOut.setMessage("����ɂ��́IHi <b>" + inboundMessage.getUser().getFirstName()
						+ "</b>! your message is: " + inboundMessage.getMessageText()
						+ "<a href=\"http://www.hoge.com/\">aaaa</a> streamID:"
						+ inboundMessage.getStream().getStreamId());
				File files[] = new File[1];
				files[0] = new File("pom.xml");
				messageOut.setAttachment(files);
				_botClient.getMessagesClient().sendMessage(inboundMessage.getStream().getStreamId(), messageOut);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onRoomCreated(RoomCreated roomCreated) {
			System.out.println("onRoomCreated.");
		}

		public void onRoomDeactivated(RoomDeactivated roomDeactivated) {
			System.out.println("onRoomDeactivated.");
		}

		public void onRoomMemberDemotedFromOwner(RoomMemberDemotedFromOwner roomMemberDemotedFromOwner) {
			System.out.println("onRoomMemberDemotedFromOwner called.");
		}

		public void onRoomMemberPromotedToOwner(RoomMemberPromotedToOwner roomMemberPromotedToOwner) {
			System.out.println("onRoomMemberPromotedToOwner called.");
		}

		public void onRoomUpdated(RoomUpdated roomUpdated) {
			System.out.println("onRoomUpdated called.");
		}

		public void onUserJoinedRoom(UserJoinedRoom userJoinedRoom) {
			System.out.println("onUserJoinedRoom called.");
			OutboundMessage messageOut = new OutboundMessage();
			messageOut.setMessage("Welcome " + userJoinedRoom.getAffectedUser().getFirstName() + "!");
			try {
				_botClient.getMessagesClient().sendMessage(userJoinedRoom.getStream().getStreamId(), messageOut);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onUserLeftRoom(UserLeftRoom userLeftRoom) {
			System.out.println("onUserLeftRoom called.");
		}

		public void onRoomReactivated(Stream stream) {
			System.out.println("onRoomReactivated called.");
		}
	}

	public static void main(String[] args) {
		new EchoBot();
	}

}
