package jp.ne.sakura.jun28.symphonytest;

import java.util.Arrays;

public class HttpResponse {

	private static final String CONTENT_TYPE_TEXT_LIST[] = { "text/html", "text/plain" };
	private static final String CONTENT_TYPE_IMAGE_LIST[] = { "image/jpeg", "image/png", "image/gif", "image/bmp" };

	private String _contentType;
	private byte _content[];

	public HttpResponse(String contentType, byte[] content) {
		super();
		_contentType = contentType;
		_content = content;
	}

	public String getImageExtension() {
		String contentType = getSimpleContentType();
		contentType = contentType.toLowerCase();
		if (contentType.endsWith("png")) {
			return "png";
		} else if (contentType.endsWith("gif")) {
			return "gif";
		} else if (contentType.endsWith("bmp")) {
			return "bmp";
		} else {
			return "jpg";
		}
	}

	public String getFileExtension() {
		String contentType = getSimpleContentType();
		contentType = contentType.toLowerCase();
		if (contentType.endsWith("pdf")) {
			return "pdf";
		} else if (contentType.endsWith("vnd.ms-excel")) {
			return "xls";
		} else if (contentType.endsWith("vnd.ms-powerpoint")) {
			return "ppt";
		} else if (contentType.endsWith("msword")) {
			return "doc";
		} else if (contentType.endsWith("zip")) {
			return "zip";
		} else {
			return "txt";
		}
	}

	private String getSimpleContentType() {
		if (Utility.isEmptyString(_contentType)) {
			return "";
		}
		int pos = _contentType.indexOf(";");
		if (pos < 0) {
			return _contentType;
		}
		return _contentType.substring(0, pos);
	}

	public boolean isResponesTypeText() {
		String contentType = getSimpleContentType();
		for (String text : CONTENT_TYPE_TEXT_LIST) {
			if (text.equalsIgnoreCase(contentType)) {
				return true;
			}
		}
		return false;
	}

	public boolean isResponesTypeImage() {
		String contentType = getSimpleContentType();
		for (String text : CONTENT_TYPE_IMAGE_LIST) {
			if (text.equalsIgnoreCase(contentType)) {
				return true;
			}
		}
		return false;
	}

	public String getContentType() {
		return _contentType;
	}

	public void setContentType(String contentType) {
		_contentType = contentType;
	}

	public byte[] getContent() {
		return _content;
	}

	public void setContent(byte[] content) {
		_content = content;
	}

	@Override
	public String toString() {
		return "HttpResponse [_contentType=" + _contentType + ", _content=" + Arrays.toString(_content) + "]";
	}

}
