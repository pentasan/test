package jp.ne.sakura.jun28.symphonytest;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MessageLog implements Serializable {

	private static final long serialVersionUID = -5531395231988599214L;

	private static final String LOG_FILE_NAME = "message.log";

	private String _type;
	private long _time;
	private String _roomName;
	private String _message;

	public MessageLog(String type, long time, String roomName, String message) {
		super();
		_type = type;
		_time = time;
		_roomName = roomName;
		_message = message;
	}

	public String getType() {
		return _type;
	}

	public void setType(String type) {
		_type = type;
	}

	public String getTimeForDisplay() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");
		Date resultdate = new Date(_time);
		return format.format(resultdate);
	}

	public long getTime() {
		return _time;
	}

	public void setTime(long time) {
		_time = time;
	}

	public String getRoomName() {
		return _roomName;
	}

	public void setRoomName(String roomName) {
		_roomName = roomName;
	}

	public String getMessage() {
		return _message;
	}

	public void setMessage(String message) {
		_message = message;
	}

	public static List<MessageLog> getMessageLogList() throws Exception {
		ObjectInputStream in = null;
		List<MessageLog> ret = new ArrayList<MessageLog>();
		try {
			in = new ObjectInputStream(new FileInputStream(LOG_FILE_NAME));
			while (true) {
				Object obj = in.readObject();
				if (obj == null) {
					break;
				}
				if (obj instanceof MessageLog) {
					ret.add((MessageLog) obj);
				}
			}
		} catch (EOFException e) {
			// reached end of file
		} catch (Exception e) {
			throw e;
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e) {
				}
				in = null;
			}
		}
		return ret;
	}

	public static synchronized void appendLog(MessageLog messageLog) throws Exception {
		ObjectOutputStream out = null;
		try {
			File file = new File(LOG_FILE_NAME);
			if (file.exists()) {
				out = new AppendingObjectOutputStream(new FileOutputStream(LOG_FILE_NAME, true));
			} else {
				out = new ObjectOutputStream(new FileOutputStream(LOG_FILE_NAME, true));
			}
			out.writeObject(messageLog);
		} catch (Exception e) {
			throw e;
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
				out = null;
			}
		}
	}

	private static class AppendingObjectOutputStream extends ObjectOutputStream {

		public AppendingObjectOutputStream(OutputStream out) throws IOException {
			super(out);
		}

		@Override
		protected void writeStreamHeader() throws IOException {
			reset();
		}
	}

	@Override
	public String toString() {
		return "MessageLog [_type=" + _type + ", _time=" + _time + ", _roomName=" + _roomName + ", _message=" + _message
				+ "]";
	}

}
