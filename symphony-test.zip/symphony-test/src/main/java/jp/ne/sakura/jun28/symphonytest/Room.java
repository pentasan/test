package jp.ne.sakura.jun28.symphonytest;

public class Room {

	private String _id;
	private String _name;

	public Room(String id, String name) {
		super();
		_id = id;
		_name = name;
	}

	public String getId() {
		return _id;
	}

	public void setId(String id) {
		_id = id;
	}

	public String getName() {
		return _name;
	}

	public void setName(String name) {
		_name = name;
	}

	@Override
	public String toString() {
		return "Room [_id=" + _id + ", _name=" + _name + "]";
	}

}
