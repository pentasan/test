package jp.ne.sakura.jun28.symphonytest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

import configuration.SymConfig;

public class Utility {

	public static void saveFileContent(String fileName, byte b[]) throws Exception {
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(new File(fileName));
			out.write(b);
		} catch (Exception e) {
			throw e;
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (Exception e) {
				}
				out = null;
			}
		}
	}

	public static void saveTextFileContent(String fileName, String content) throws Exception {
		FileWriter fw = null;
		try {
			fw = new FileWriter(new File(fileName));
			fw.write(content);
		} catch (Exception e) {
			throw e;
		} finally {
			if (fw != null) {
				try {
					fw.close();
				} catch (Exception e) {
				}
				fw = null;
			}
		}
	}

	public static String loadTextFileContent(String fileName) throws Exception {
		int BUFFER_LEN = 1024;
		StringBuffer sb = new StringBuffer();
		FileReader fr = null;
		char b[] = new char[BUFFER_LEN];
		try {
			fr = new FileReader(new File(fileName));
			while (true) {
				int len = fr.read(b, 0, BUFFER_LEN);
				if (len < 0) {
					break;
				}
				sb.append(b, 0, len);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			if (fr != null) {
				try {
					fr.close();
				} catch (Exception e) {
				}
				fr = null;
			}
		}

		return sb.toString();
	}

	public static boolean isEmptyString(String s) {
		if (s == null || s.length() <= 0) {
			return true;
		}
		return false;
	}

	public static SymConfig getSymConfig() {
		SymConfig config = new SymConfig();
		config.setSessionAuthHost("develop2.symphony.com");
		config.setSessionAuthPort(443);
		config.setKeyAuthHost("develop2.symphony.com");
		config.setKeyAuthPort(443);
		config.setPodHost("develop2.symphony.com");
		config.setPodPort(443);
		config.setAgentHost("develop2.symphony.com");
		config.setAgentPort(443);
		config.setBotPrivateKeyPath("cfg/");
		config.setBotPrivateKeyName("innovatebot_179_privatekey.pem");
		config.setBotEmailAddress("innovate_bot_179@devmeetup.com");
		config.setBotUsername("innovate_bot_179");
		config.setAuthTokenRefreshPeriod(30);
		return config;
	}
}
