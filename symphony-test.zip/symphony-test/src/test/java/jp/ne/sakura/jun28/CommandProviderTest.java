package jp.ne.sakura.jun28;

import jp.ne.sakura.jun28.symphonytest.Command;
import jp.ne.sakura.jun28.symphonytest.CommandProvider;

public class CommandProviderTest {

	public static void main(String args[]) {
		try {
			System.out.println("list:" + CommandProvider.getInstance().getCommandList());
			Command command = new Command("command", "parameter", "detail", "http://www.hoge.com");
			CommandProvider.getInstance().addCommand(command);
			CommandProvider.getInstance().saveData();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
