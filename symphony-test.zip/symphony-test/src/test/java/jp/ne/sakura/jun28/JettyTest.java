package jp.ne.sakura.jun28;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.eclipse.jetty.server.Handler;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.DefaultHandler;
import org.eclipse.jetty.server.handler.HandlerList;
import org.eclipse.jetty.server.handler.ResourceHandler;
import org.eclipse.jetty.servlet.ServletHandler;

public class JettyTest {

	public static void main(String args[]) {

		try {
			Server server = new Server(8080);

			ResourceHandler resourceHandler = new ResourceHandler();
			resourceHandler.setDirectoriesListed(true);
			resourceHandler.setWelcomeFiles(new String[] { "index.html" });
			resourceHandler.setResourceBase("web");

			ServletHandler handler = new ServletHandler();
			server.setHandler(handler);
			handler.addServletWithMapping(TopPageServlet.class, "/top");

			HandlerList handlers = new HandlerList();
			handlers.setHandlers(new Handler[] { resourceHandler, handler, new DefaultHandler() });
			server.setHandler(handlers);

			server.start();
			server.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static class TopPageServlet extends HttpServlet {
		private static final long serialVersionUID = -5730270365520062867L;

		@Override
		protected void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {

			VelocityEngine velocityEngine = new VelocityEngine();
			velocityEngine.init();
			Template t = velocityEngine.getTemplate("web/top.tpl");
			VelocityContext context = new VelocityContext();
			context.put("", "");
			StringWriter writer = new StringWriter();
			t.merge(context, writer);

			response.setContentType("text/html");
			response.setStatus(HttpServletResponse.SC_OK);
			response.getWriter().println(writer.getBuffer().toString());
		}
	}
}
