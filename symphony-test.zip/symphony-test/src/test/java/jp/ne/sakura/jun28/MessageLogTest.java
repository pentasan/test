package jp.ne.sakura.jun28;

import java.util.List;

import jp.ne.sakura.jun28.symphonytest.MessageLog;

public class MessageLogTest {

	public static void main(String args[]) {
		try {
			MessageLog messageLog = new MessageLog("IN", System.currentTimeMillis(), "Room A",
					"Hello World!\r\n����ɂ��͐��E�I");
			MessageLog.appendLog(messageLog);

			List<MessageLog> list = MessageLog.getMessageLogList();
			for (MessageLog msg : list) {
				System.out.println("messageLog:" + msg);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
